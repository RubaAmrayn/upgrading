if('serviceWorker' in navigator)
{
    try {
        navigator.serviceWorker.register('../code_challenge/sw.js'); 
    } catch (error) {
     
    }
}
if(window.location.hash=="#" || window.location.hash=="")
    {
        getAdd()
    }
    else if(window.location.hash.includes("search"))
    {
        console.log('hash is ',window.location.hash)
        var value = window.location.hash
        var val_arr =  value.split('=');
 
         search(val_arr[1])
    }
    else
    {
        getPage()
    }
    $(window).on('load',()=>{
        var win = $(this);
    if (win.width() < 580) {
  
      $('#option_row')
      .removeClass('col-6')
      .addClass('col-12');
      $('#res_title').removeClass('col-8').addClass('col-12');
      $('#res_desc').removeClass('col-8').addClass('col-12');
      $('#res_icons').removeClass('col-7').addClass('col-12');
      $('#res_code').removeClass('col-8').addClass('col-12');
    } 
    else 
    { 
      $('#option_row')
      .removeClass('col-12')
      .addClass('col-6');
      $('#res_title').removeClass('col-12').addClass('col-8');
      $('#res_desc').removeClass('col-12').addClass('col-8');
      $('#res_icons').removeClass('col-12').addClass('col-7');
      $('#res_code').removeClass('col-12').addClass('col-8');
    }
    })
    $(window).on('focus',()=> 
    {
        
        var win = $(this);
        if (win.width() < 580) {
            $('#option_row').removeClass('col-6').addClass('col-12');
            $('#res_title').removeClass('col-8').addClass('col-12');
            $('#res_desc').removeClass('col-8').addClass('col-12');
            $('#res_icons').removeClass('col-7').addClass('col-12');
            $('#res_code').removeClass('col-8').addClass('col-12');
          } 
          else 
          { 
            $('#option_row').removeClass('col-12') .addClass('col-6');
            $('#res_title').removeClass('col-12').addClass('col-8');
            $('#res_desc').removeClass('col-12').addClass('col-8');
            $('#res_icons').removeClass('col-12').addClass('col-7');
            $('#res_code').removeClass('col-12').addClass('col-8');
          }
    })
$(window).on('hashchange',() =>
{
   
    if(window.location.hash=="#" || window.location.hash=="")
    {
        getAdd()
    }
    else if(window.location.hash.includes("search"))
    {
       
        var value = window.location.hash
        var val_arr =  value.split('=');
 
         search(val_arr[1])
    }
    else
    {
        getPage()
    }
})

$(window).on('resize', ()=> {
    var win = $(this);
    if (win.width() < 580) {
  
        $('#option_row')
        .removeClass('col-6')
        .addClass('col-12');
        $('#res_title').removeClass('col-8').addClass('col-12');
        $('#res_desc').removeClass('col-8').addClass('col-12');
        $('#res_icons').removeClass('col-7').addClass('col-12');
        $('#res_code').removeClass('col-8').addClass('col-12');
      } 
      else 
      { // >419
        $('#option_row')
        .removeClass('col-12')
        .addClass('col-6');
        $('#res_title').removeClass('col-12').addClass('col-8');
        $('#res_desc').removeClass('col-12').addClass('col-8');
        $('#res_icons').removeClass('col-12').addClass('col-7');
        $('#res_code').removeClass('col-12').addClass('col-8');
      }
  });


function getPage()
{
   
    $.ajax({
        url:'view_code.php',
        method:'POST',
        dataType:'html',
        success: response =>
        {
         $('#dynamic_content').html(response);
         
        }
    })
    return false;
}
function getAdd()
{
    
    $.ajax({
        url:'AddNewCode.php',
        method:'GET',
        dataType:'html',
        success: response =>
        {
         $('#dynamic_content').html(response);
        }
    })
    return false;
}


function search(search_val){
    
    $.ajax({
        url:'search.php?val='+search_val,
        method:'POST',
        dataType:'html',
        success: response =>
        {
         $('#dynamic_content').html(response);
        }
    })
    return false;
}
function begin_search()
{
    window.location.hash = 'search='+$('#txt_search').val()
    return false;
}