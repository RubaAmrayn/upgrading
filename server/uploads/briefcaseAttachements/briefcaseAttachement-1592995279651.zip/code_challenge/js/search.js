    $('document').ready(()=>{
      
        var search_data = 
        {
            text_search: search_val
        }
   
    $.ajax({
        
        url:'api/search.php',
        method:'POST',
        data:JSON.stringify(search_data),
        dataType:'JSON',
        success: response =>
        {
            var resutl="";
            resutl+='<ul>';
           for(var i =0;i<response.length;i++)
           {
            resutl+='<li class="search_result"><a href="#'+response[i].page_id+'")"> <h5>'+response[i].title+'</h4></a><small>'+response[i].code_desc+'</small></li>';
           }
           resutl+='</ul>';
            $('#search_result').html(resutl)
            return false;
        }
        
    })
        return false;
    })
    


