
$('document').ready(function(){
    var win = $(window);
    if (win.width() < 580) {
  
        $('#option_row')
        .removeClass('col-6')
        .addClass('col-12');
        $('#res_title').removeClass('col-8').addClass('col-12');
        $('#res_desc').removeClass('col-8').addClass('col-12');
        $('#res_icons').removeClass('col-7').addClass('col-12');
        $('#res_code').removeClass('col-8').addClass('col-12');
      } 
      else 
      { 
        $('#option_row')
        .removeClass('col-12')
        .addClass('col-6');
        $('#res_title').removeClass('col-12').addClass('col-8');
        $('#res_desc').removeClass('col-12').addClass('col-8');
        $('#res_icons').removeClass('col-12').addClass('col-7');
        $('#res_code').removeClass('col-12').addClass('col-8');
      }
   $('#code_form').validate({
       rules:
       {
            code_area:
            {
                required:true
            },
            syntax_list:
            {
                required:true
            },
            expired_list:
            {
                required:true
            },
            
            title:
            {
                required:true,
                minlength: 5     
            }
       },
        messages:
        {
            code_area:
            {
                required:"this Field Required"
            },
            syntax_list:
            {
                required:"this Field Required"
            },
            expired_list:
            {
                required:"this Field Required"
            },
            
            title:
            {
                required:"this Field Required",
                minlength: "Must be at least 5 characters"     
            }
        },
        submitHandler: ()=>
        {
          var data = 
          {
            code_area : $('#code_area').val(),
            syntax_list : $('#syntax_list').val(),
            expired_list : $('#expired_list').val(),
            desc : $('#desc').val(),
            title : $('#title').val()
          }

          $.ajax({
              url:'api/insert_code.php',
              method:'POST',
              data: JSON.stringify(data),
              dataType:'JSON',
              success: response =>
              {
                if(response.status)
                {
                    swal({
                        title:'Success!',
                        type:'success',
                        html:'<p class="text-success">Your Code has been inserted!</p>'
                    });
                    setTimeout(() => {
                        window.location.href="?#"+response.page_id;
                    }, 3000);
                }
                else
                {
                    swal({
                        title:'Error!',
                        type:'error',
                        html:'<p class="text-danger">Error When insert Your Code!</p>'
                    });
                }
              }
          })
          
        }
   })
})