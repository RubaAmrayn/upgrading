var win = $(window);
    if (win.width() < 580) {
  
        $('#option_row')
        .removeClass('col-6')
        .addClass('col-12');
        $('#res_title').removeClass('col-8').addClass('col-12');
        $('#res_desc').removeClass('col-8').addClass('col-12');
        $('#res_icons').removeClass('col-7').addClass('col-12');
        $('#res_code').removeClass('col-8').addClass('col-12');
      } 
      else 
      {
        $('#option_row')
        .removeClass('col-12')
        .addClass('col-6');
        $('#res_title').removeClass('col-12').addClass('col-8');
        $('#res_desc').removeClass('col-12').addClass('col-8');
        $('#res_icons').removeClass('col-12').addClass('col-7');
        $('#res_code').removeClass('col-12').addClass('col-8');
      }
 
var page = window.location.href;

var splitted_page = page.split('#');
var data = {
    page_id : splitted_page[1]
}
var page_title = "";
$.ajax({
    url:'api/getPageById.php',
    method:'POST',
    data:JSON.stringify(data),
    dataType:'JSON',
    cache:false,
    success: response => 
    {
        $('#code_title').text(response.title)
        document.title = response.title; //set value
        page_title = document.title;
        $('#code_desc').text(response.code_desc)
        $('#date').text(' '+response.date+' ')
        $('#visitings').text(' '+response.visitings+' ')
        $('#expire').text(' '+response.expire_date+' ')
        $('#code').html('<pre><code class="">'+response.content+'</code></pre>')
        
        $('#language').text(response.language)
        InitShares();
    }

})
$('#btn_download').on('click', ()=>
{
    let page_id = window.location.hash.replace('#','');
    let content = $('#code').text();
    let textFileblob = new Blob([content],{type:'text/plain'});
    let download_link = document.createElement("a");
    download_link.download = page_id+".txt"
    download_link.innerHTML = "download file"
    if(window.webkitURL != null)
    {
        download_link.href = window.webkitURL.createObjectURL(textFileblob)
    }
    else
    {
        download_link.href = window.webkitURL.createObjectURL(textFileblob)
        download_link.style.display = "none"
        document.body.appendChild(download_link)
    }
    console.log(download_link.href)
    download_link.click();
})

$('#btn_print').on('click', ()=>
{
    $('#code').append($('#language').text()+"<br>"+$('#date').text())
    $('#code').print();
})

const InitShares = () =>
{
    $('#share').jsSocials({
        shares: ["email", "twitter", "facebook", "googleplus", "linkedin", "pinterest", "stumbleupon", "pocket", "whatsapp", "viber", "messenger", "vkontakte", "telegram", "line"],
        url: window.location.href,
        text: document.title /* get value*/,
        showLabel: true,
        showCount: true,
        shareIn: "popup"
    });
}
