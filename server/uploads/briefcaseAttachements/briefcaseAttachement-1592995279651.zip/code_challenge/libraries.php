<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/bootstrap.min.css"> 
<!-- <link rel="stylesheet" href="css/select2.min.css"> -->
<link rel="stylesheet" href="css/style_pages.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/jssocials.css" />
<link rel="stylesheet" type="text/css" href="css/jssocials-theme-minima.css" />
<script src="js/jquery.min.js" defer></script>
<script src="js/bootstrap.min.js" defer></script>
<script src="js/popper.min.js" defer></script>
<!-- <script src="js/scrollreveal.min.js" defer></script> -->
<script src="js/jquery.validate.min.js" defer></script>
<!-- <script src="js/select2.min.js" defer></script> -->
<script src="js/sweetalert2.all.min.js" defer></script>
<script src="js/jQuery.print.min.js" defer></script>
<script src="js/jssocials.min.js" defer></script>
<script src="js/app.js" defer></script> 



 
        
  
