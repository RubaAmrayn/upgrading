const static_Assets = [
    '.',
    './',
    './manifest.json',
    './libraries.php',
    './navbar.php',
    './search.php',
    './AddNewCode.php',
    './View_Code.php',
    './css/bootstrap.min.css',
    './css/select2.min.css',
    './css/style_pages.css',
    './font-awesome-4.7.0/css/font-awesome.min.css',
    './css/jssocials.css',
    './css/jssocials-theme-minima.css',
    './js/jquery.min.js',
    './js/bootstrap.min.js',
    './js/popper.min.js',
    './js/scrollreveal.min.js',
    './js/jquery.validate.min.js',
    './js/select2.min.js',
    './js/sweetalert2.all.min.js',
    './js/jQuery.print.min.js',
    './js/jssocials.min.js',
    './js/app.js',
    './images/img.webp',
    './images/logo.webp'
]
var v = '1.0';
self.addEventListener('install', async  event => {
    const cache = await caches.open('static_pages '+v);
    cache.addAll(static_Assets);
    // console.log('Static Pages Cached')
  });

self.addEventListener('fetch',event => {
    const req = event.request;
    const url = new URL(req.url);
    if(url.origin == location.origin)
    {
        event.respondWith(cacheFirst(req));
    }
    else
    {
        event.respondWith(networkFirst(req));
    }
 
});

 const cacheFirst = async (req) => {
    const cachedResponse = await caches.match(req);
    return cachedResponse || fetch(req);
}
const networkFirst = async (req) =>
{
    const cache = await caches.open('dynamic_pages');
    try 
    {
        const res = await fetch(req);
        cache.put(req,res.clone());
        return res;
    } catch (error) 
    {
       const cachedResponse = await cache.match(req);
    //    console.log(cachedResponse);
       
       return cachedResponse || await caches.match('./fallback.json');
    }
}
