
<form action="" method="post" id="code_form">
    <div class="row">
        <div class="col-sm-12">
           <div class="card">
               <div class="card-header">
               <label for="">New Code</label>
               </div>
               <div class="card-body">
               
            <textarea name="code_area" id="code_area" cols="30" rows="10" class="form-control"></textarea>
               </div>
           </div>
        </div>
    </div>

    <div class="row">
        <div class="col-6" id="option_row">
                <div class="row" style="margin-top:10px;">
                        <div class="col-sm-5">
                            <label for="" class="label">Syntax Highlighting:</label>
                        </div>
                        <div class="col-sm-7">
                            <select name="syntax_list" id="syntax_list" class="form-control" style="color:#001a33">
                                <option value="">Select one...</option>
                                <option value="php">PHP</option>
                                <option value="html">HTML</option>
                                <option value="css">CSS</option>
                                <option value="javascript">JAVASCRIPT</option>
                                <option value="python">PYTHON</option>
                                <option value="java">JAVA</option>
                                <option value="c#">C#</option>
                                <option value="ruby">RUBY</option>
                                <option value="sql">SQL</option>
                                <option value="apache">APACHE</option>
                                <option value="nginx">NGINX</option>
                                <option value="vbnet">VB.NET</option>
                                <option value="cpp">C++</option>
                                <option value="c">C</option>
                            </select>
                        </div>
                </div>
                <div class="row" style="margin-top:10px;">
                        <div class="col-sm-5">
                            <label for="" class="label">Paste Expiration:</label>
                        </div>
                        <div class="col-sm-7">
                            <select name="expired_list" id="expired_list" class="form-control" style="color:#001a33">
                                <option value="">Select one...</option>
                                <option value="none">NONE</option>
                                <option value="10I">10 Minute</option>
                                <option value="1H">1 Hour</option>
                                <option value="1D">1 Day</option>
                                <option value="1W">1 Week</option>
                                <option value="1M">1 Month</option>
                                <option value="1Y">1 Year</option>
                            </select>
                        </div>
                </div>
                <div class="row" style="margin-top:10px;">
                        <div class="col-sm-5">
                            <label for="" class="label">Code Description:</label>
                        </div>
                        <div class="col-sm-7">
                           <textarea name="desc" id="desc" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                </div>

                <div class="row" style="margin-top:10px;">
                        <div class="col-sm-5">
                            <label for="" class="label">Code Name/Title:</label>
                        </div>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" id="title" name="title">
                        </div>
                </div>
                <div class="row" style="margin-top:10px;">
                        <div class="col-sm-5">
                           
                        </div>
                        <div class="col-sm-7">
                        <button class="mybutton btn-block" id="btn_send">Create New Code</button>
                        </div>
                </div>

        </div>


        <div class="col-6"></div>
    </div>
</form>
<script src="js/AddNewCode.js"></script>
<br>