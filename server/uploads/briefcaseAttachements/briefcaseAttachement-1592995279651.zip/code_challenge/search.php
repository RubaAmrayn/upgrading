<div class="row">
    <div class="col-8 col-sm-12" id="res_code">
        <div class="card">
            <div class="card-header">
                <div class="left">
                <span id="language">
               
                </span>
                </div>
               
            </div>
            <div class="card-body" id="search_result">
               <!--  -->
            </div>
            
        </div>
    </div>
    <div class="col-4 col-sm-12"></div>
</div>
<script>
    var search_val='<?php echo $_GET['val'] ?>'
</script>
<script src="js/search.js"></script>