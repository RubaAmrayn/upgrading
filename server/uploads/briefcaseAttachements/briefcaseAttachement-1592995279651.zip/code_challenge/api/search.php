<?php
$_POST = json_decode(file_get_contents('php://input'),true);
require('connect.php');
$text_search = $mysqli->real_escape_string($_POST['text_search']);
$search_query = "SELECT * FROM `pages` WHERE `page_id` LIKE '%$text_search%' OR `title` LIKE '%$text_search%' OR 
`language` LIKE '%$text_search%' OR `content` LIKE '%$text_search%'";
$result = $mysqli->query($search_query);
if($result->num_rows > 0)
{
    // اذا عندي نتائج بحث
    $data = array();
    $count = 0;
    while($row = $result->fetch_assoc())
    {
        $data[$count]['page_id'] = $row['page_id'];
        $data[$count]['title']  = $row['title'];
        $data[$count]['language'] = $row['language'];
        $data[$count]['code_desc'] = $row['code_desc'];
        $count+=1;
    }
    header('Content-Type: application/json');
    echo json_encode($data);
}
else
{

}
?>