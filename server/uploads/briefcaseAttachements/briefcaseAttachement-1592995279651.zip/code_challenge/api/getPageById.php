<?php
function _e($string)
{
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    
}
$_POST = json_decode(file_get_contents('php://input'),true);
require('connect.php');
$page_id = $mysqli->real_escape_string($_POST['page_id']);
$getPageQuery = "SELECT * FROM `pages` WHERE page_id = '$page_id'";
$result = $mysqli->query($getPageQuery);
if($result->num_rows > 0)
{
    $data = array();
    $row = $result->fetch_assoc();
    $data['page_id'] = _e($row['page_id']);
    $data['title'] = _e($row['title']);
    $data['language'] = _e($row['language']);
    $data['content'] = _e($row['content']);
    $data['code_desc'] = _e($row['code_desc']);
    $data['date'] = _e($row['date']);
    $data['expire_date'] = _e($row['expire_date']);
    $data['visitings'] = _e($row['visitings']);
    $data['visitings']+=1;
   
    $visitings = $data['visitings'];
    $updateVisitings = "UPDATE `pages` SET `visitings` = '$visitings' WHERE `page_id` = '$page_id'";
    $mysqli->query($updateVisitings);
    header('Content-Type: application/json');
    echo json_encode(array(
        'page_id'=>$data['page_id'],
        'title'=>$data['title'],
        'language'=>$data['language'],
        'content'=>$data['content'],
        'code_desc'=>$data['code_desc'],
        'date'=>$data['date'],
        'expire_date'=>$data['expire_date'],
        'visitings'=>$data['visitings']
    ));
}
else
{
    header('Content-Type: application/json');
    echo json_encode(array("status"=>"no data found!"));
}
?>