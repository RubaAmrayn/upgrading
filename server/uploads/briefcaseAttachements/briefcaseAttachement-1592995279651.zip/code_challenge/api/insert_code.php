<?php
function random_id($length)
{
    $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijqlmnopqrstuvwxyz";
    $character_length = strlen($characters);
    $random_str = "";
    for($i=0;$i<=$length;$i++)
    {
        $random_str .= $characters[rand(0,$character_length-1)];
    }
    return $random_str;
}
$_POST = json_decode(file_get_contents('php://input'),true);
require('connect.php');
$page_id = random_id(10);
$code_area = $mysqli->real_escape_string($_POST['code_area']);
$syntax_list = $mysqli->real_escape_string($_POST['syntax_list']);
$date = date('Y/m/d H:i:s');
$expired_list = $mysqli->real_escape_string($_POST['expired_list']);
$desc = $mysqli->real_escape_string($_POST['desc']);
$title = $mysqli->real_escape_string($_POST['title']);
$visitings = "0";

$insert_query = "INSERT INTO `pages` VALUES('$page_id','$title','$syntax_list','$code_area','$desc',
'$date','$expired_list','$visitings')";
$result = $mysqli->query($insert_query);
if($result === TRUE)
{
    $response = array("status"=>true,"page_id"=>$page_id);
    header('Content-Type: application/json');
    echo json_encode($response);
}
else
{
    $response = array("status"=>false);
    header('Content-Type: application/json');
    echo json_encode($response);
}
 
?>