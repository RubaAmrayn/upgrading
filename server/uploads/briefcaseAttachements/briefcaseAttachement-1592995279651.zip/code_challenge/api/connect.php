<?php
    define("SERVER_NAME","Localhost");
    define("USER_NAME","root");
    define("PASSWORD","");
    define("DATABASE","code_challenge");
    try
    {
    $mysqli = new mysqli(SERVER_NAME,USER_NAME,PASSWORD,DATABASE);
    
    }
    catch(Exception $e)
    {
        echo $e->getMessage();
    }
?>