
<div class="row">
    <div class="col-8" id="res_title">
       <h2 class="text-left" id="code_title" style="color:#001a33"></h2>
    </div>
    <div class="col-7">
    
    </div>
</div>
<div class="row">
    <div class="col-8" id="res_desc">
       <h4 class="text-left" id="code_desc" style="color:#001a33"></h4>
    </div>
    <div class="col-7">
    
    </div>
</div>
<div class="row">
<div class="col-7 " id="res_icons">
<i class="fa fa-calendar" id="date" style="color:#001a33"></i>
<i class="fa fa-eye" id="visitings" style="color:#001a33"></i>
<i class="fa fa-clock-o" id="expire" style="color:#001a33"></i>
</div>
<dic class="col-5 "></dic>
</div>
<div class="row">
    <div class="col-10" id="res_code">
        <div class="card">
            <div class="card-header">
                <div class="left">
                <span id="language">
               
                </span>
                </div>
                <div class="right">
                <button type="button" class="btn btn-sm header-button" data-toggle="modal" data-target="#sharing_modal"><i class="fa fa-share-alt"></i></button>
                <button class="btn btn-sm header-button" id="btn_download"><i class="fa fa-download"></i></button>
                <button class="btn btn-sm header-button" id="btn_print"><i class="fa fa-print"></i></button>
                </div>
            </div>
            <div class="card-body" id="code">
               
            </div>
            
        </div>
    </div>
    <div class="col-4">
        
    </div>
</div>
<div class="modal fade" id="sharing_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Share your Code</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="share">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>
<script src="js/view_code.js"></script>