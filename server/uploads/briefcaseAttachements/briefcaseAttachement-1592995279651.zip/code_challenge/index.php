<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="theme-color" content="#251c1c">
    <title>Code Challenge</title>
    <?php
    require('libraries.php');
    ?>
</head>
<body>  
<div class="header">
<?php
require('navbar.php');
?>
</div>
<br>

<div class="container" id="dynamic_content"></div>


<footer style="margin-top:10px">
   <div class="card ">
       <div class="card-header">
           All Rights saved to myCode Challenge&copy; 2018
       </div>
   </div>
</footer>
</body>
</html>