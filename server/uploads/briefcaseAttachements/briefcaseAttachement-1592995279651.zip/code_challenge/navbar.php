<nav class="navbar navbar-toggleable-md navbar-light bg-faded">
  <button class="navbar-toggler navbar-toggler-right" type="button"  style="color:white" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="fa fa-navicon" style="color:white !important" ></span>
  </button>
  <a class="navbar-brand" href="#"><img src="images/logo.webp" alt=""></a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#" onclick="getAdd()"><button class="btn btn-success btn-sm">+ New Code</button></a>
      </li>
      <li class="nav-item">
      <form class="form-inline my-2 my-lg-0">
      <i class="fa fa-search" style="color:#3a2c2c;margin-top:10px;"></i>
     <input type="text" class="text-search" id="txt_search" placeholder="search...">
     <button class="btn btn-sm btn-success" style="margin-top:10px; margin-left:10px;" onclick="begin_search()">Search</button>
    </form>
      </li>
    </ul>
  </div>
</nav>